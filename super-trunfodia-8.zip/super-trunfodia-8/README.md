# Super Trunfo - Dia 8

A Pen created on CodePen.io. Original URL: [https://codepen.io/jonatasvalesi/pen/ZEoeyQm](https://codepen.io/jonatasvalesi/pen/ZEoeyQm).

